<?php
//MiniMVC - Github JPAKaagman
//Licensed under the GNU GPL License
namespace MiniMVC\Controller {
    
    require_once(WEBSITE_FILEPATH . '/views/createView.php');
    require_once(WEBSITE_FILEPATH . '/routes/example.php');
    use MiniMVC\Route as Route;
    use MiniMVC\View as View;

    class Example extends Route\Example {
    	
    	public function __construct($page) {
    		$this->Begin();
    		$this->LoadPage($page);
    	}
    	
    	public function LoadPage($page) {
    		$htmldata = array(
    			"WebsiteURL"		=> WEBSITE_ADDRESS,
    			"WebsiteName"		=> WEBSITE_NAME,
    			"ServerYear"		=> SERVER_YEAR
    		);
    	
    		switch ($page) {
    			case "home":
    				$filename = "example/home.html";
    				View\Create::Page($filename, $htmldata, $this->doContinue);
    			break;
    			default:
    				//Page not found, exit the script
    				die();
    			break;
    		}
    	}
    }
}