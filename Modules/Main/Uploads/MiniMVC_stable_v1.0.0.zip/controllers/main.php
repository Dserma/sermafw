<?php
//MiniMVC - Github JPAKaagman
//Licensed under the GNU GPL License
namespace MiniMVC\Controller {
    
    require_once(WEBSITE_FILEPATH . '/views/createView.php');
    require_once(WEBSITE_FILEPATH . '/routes/main.php');
    use MiniMVC\Route as Route;
    use MiniMVC\View as View;


    class Main extends Route\Main {
    	
    	public function __construct($page) {
    		$this->Begin();
    		$this->LoadPage($page);
    	}
    	
    	public function LoadPage($page) {
    		$htmldata = array(
    			"WebsiteURL"		=> WEBSITE_ADDRESS,
    			"WebsiteName"		=> WEBSITE_NAME,
    			"ServerYear"		=> SERVER_YEAR
    		);
    	
    		switch ($page) {
    			case "home":
    				$filename = "main/home.html";
    				View\Create::Page($filename, $htmldata, $this->doContinue);
    			break;
    			case "error":
    			    //Set 404 error header
    			    header("HTTP/1.0 404 Not Found");
    				$filename = "main/error.html";
    				View\Create::Page($filename, $htmldata, $this->doContinue);
    			break;
    			default:
    				//Page not found, exit the script
    				die();
    			break;
    		}
    	}
    }
}