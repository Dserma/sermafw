<?php
//MiniMVC - Github JPAKaagman
//Licensed under the GNU GPL License
namespace MiniMVC\Route {
    
    require_once(WEBSITE_FILEPATH . '/controllers/example.php');
    use MiniMVC\Controller as Controller;
    
    class Example {
    	public $doContinue;
    	public $page;
    
    	public function __construct($page) {
    		$this->page = $page;
    		$this->RouteToPage();
    	}
    	
    	private function RouteToPage() {
    		switch ($this->page) {
    			case "home":
    				new Controller\Example($this->page);
    			break;
    			default:
    				//Page not found, exit the script, and return to routing for a 404 error
    				die();
    			break;
    		}
    	}
    
    	public function Begin() {
    		$this->doContinue = true;
    		return;
    	}
    }
}