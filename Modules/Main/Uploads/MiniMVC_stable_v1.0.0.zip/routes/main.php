<?php
//MiniMVC - Github JPAKaagman
//Licensed under the GNU GPL License
namespace MiniMVC\Route {
    
    require_once(WEBSITE_FILEPATH . '/controllers/main.php');
    use MiniMVC\Controller as Controller;
    
    class Main {
    	public $doContinue;
    	public $page;
    
    	public function __construct($page) {
    		$this->page = $page;
    		$this->RouteToPage();
    	}
    	
    	private function RouteToPage() {
    		switch ($this->page) {
    			case "error":
    				new Controller\Main($this->page);
    			break;
    			case "home":
    				new Controller\Main($this->page);
    			break;
    			default:
    				//Page not found, exit the script, and return to routing for a 404 error
    				die();
    			break;
    		}
    	}
    
    	public function Begin() {
    		$this->doContinue = true;
    		return;
    	}
    }
}