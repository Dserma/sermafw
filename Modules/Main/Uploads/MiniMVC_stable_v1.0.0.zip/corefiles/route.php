<?php
//MiniMVC - Github JPAKaagman
//Licensed under the GNU GPL License
namespace MiniMVC\Core {

    class Route {
    	private $_pageFound	= false;
    	private $_listUri	= array();
    	private $_listCall	= array();
    	private $_trim		= '/\^$';

    	public function Add($uri, $function) {
    		$uri				= trim($uri, $this->_trim);
    		$this->_listUri[]	= $uri;
    		$this->_listCall[]	= $function;
    	}

    	public function Submit() {
    		$uri = isset($_GET['uri']) ? $_GET['uri'] : '/';
    		$uri = trim($uri, $this->_trim);

    		$replacementValues  = array();
    		$getAllMatches      = array();

    		foreach ($this->_listUri as $listKey => $listUri) {
    			if (preg_match("#^$listUri$#", $uri)) {
    				$realUri = explode('/', $uri);
    				$fakeUri = explode('/', $listUri);
    
    				$getAllMatches[$listKey] = $listUri;
    
    				foreach ($fakeUri as $key => $value) {
    					if ($value == '.+') {
    						$replacementValues[] = $realUri[$key];
    					}
    				}
    			}
    		}
    		if(!empty($getAllMatches)) {
    			$uniqueMatches = array_unique($getAllMatches);

    			foreach($uniqueMatches as $key => $value) {
    				$arrAllLength[$key] = strlen($value);
    			}

    			krsort($arrAllLength);

    			$arrAllLength = array_flip($arrAllLength);

    			$value = array_shift($arrAllLength);
    			call_user_func_array($this->_listCall[$value], $replacementValues);
    			$this->_pageFound = true;
    		}

    		if(!$this->_pageFound) {
    			return false;
    		}
    		return true;
    	}
    }
}