<?php
//MiniMVC - Github JPAKaagman
//Licensed under the GNU GPL License
namespace MiniMVC\Core {

	class PathConfig {
		private static function IsSSL() {
			//Check if the website is called from the HTTPS or the HTTP protocol
			if((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['SERVER_PORT'] == 443)) {
				return "https://";
			}
			else {
				return "http://";
			}
		}
		
		private static function InFolder() {
			if(dirname($_SERVER['SCRIPT_NAME']) == "/") {
				return dirname($_SERVER['SCRIPT_NAME']);
			}
			else {
				return dirname($_SERVER['SCRIPT_NAME']) . '/';
			}
		}

		public static function GetWebsiteAdress() {
			return (static::IsSSL() . $_SERVER["SERVER_NAME"] . static::InFolder());
		}
	}
}