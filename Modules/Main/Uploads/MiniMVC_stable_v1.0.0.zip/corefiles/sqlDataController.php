<?php
//MiniMVC - Github JPAKaagman
//Licensed under the GNU GPL License
namespace MiniMVC\Core {

    include_once(WEBSITE_FILEPATH . "/corefiles/configuration.php");
    Configuration::ConstructSQLConfig();
    use PDO;
    use Exception;

    class SqlData {
    	private $dbHandler;

    	public function __construct() {
    		$this->SetupConnection();
    	}

    	public function SetupConnection() {
    		try {
    			//set a connection with the database
    			$this->dbHandler = new PDO(DB_HOST, DB_USER, DB_PASS);
    			$this->dbHandler->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    		}
    		catch(Exception $e) {
    			die('<script>console.log("'.$e->getMessage().'");</script>');
    		}
    	}

    	public function ModelFetch($sqlQuery, $model) {
    		//fetch sql data as a model
    		try {
    			$query = $this->dbHandler->prepare($sqlQuery);
    			$query->setFetchMode(PDO::FETCH_INTO, $model);
    			$query->execute();
    			$query->fetch();
    			return $query;
    		}
    		catch(Exception $e) {
    			die('<script>console.log("'.$e->getMessage().'");</script>');
    		}
    	}

    	public function FetchAll($sqlQuery) {
    		//fetch all data of query output
    		try {
    			$query = $this->dbHandler->prepare($sqlQuery);
    			$query->setFetchMode(PDO::FETCH_ASSOC);
    			$query->execute();
    			$query->fetch();
    			return $query;
    		}
    		catch(Exception $e) {
    			die('<script>console.log("'.$e->getMessage().'");</script>');
    		}
    	}

    	public function ExecQuery($sqlQuery, $params = null) {
    		//execute a query
    		try {
    			$query = $this->dbHandler->prepare($sqlQuery);
    			if(!empty($params)) {
    				foreach($params as $key => $val) {
    					$query->bindValue(':'.$key, $val);
    				}
    			}
    			$query->execute();
    			return $query;
    		}
    		catch(Exception $e) {
    			die('<script>console.log("'.$e->getMessage().'");</script>');
    		}
    	}

    	public function __destruct() {
    		//empty the sql connection data, close connection
    		$this->dbHandler = null;
    	}
    }
}