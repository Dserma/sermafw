<?php
//MiniMVC - Github JPAKaagman
//Licensed under the GNU GPL License
namespace MiniMVC\Core {

	require_once('path.php');
	require_once('route.php');

	//Set error reporting to show all errors
	error_reporting(E_ALL);
	ini_set('display_errors', 1);

	class Configuration {
		
		public static function ConstructSQLConfig() {
			if(!defined('DB_CONFIG')) {
				define('DB_CONFIG', 1);
				define('DB_USER', 'root');
				define('DB_PASS', 'password');
				define('DB_HOST', 'mysql:host=localhost;dbname=achievementlist');
			}
		}

		public static function ConstructGlobalConfig() {
			//Global config
			//WEBSITE_FILEPATH = exact path to the root of the script
			//WEBSITE_ADDRESS = full url to the home
			if(!defined('GLOBAL_CONFIG')) {
				define('GLOBAL_CONFIG', 1);
				define('WEBSITE_FILEPATH', dirname(dirname(__FILE__)));
				define('WEBSITE_ADDRESS', PathConfig::GetWebsiteAdress());
				define('WEBSITE_NAME', "MiniMVC");
				define('SERVER_YEAR', date("Y"));
			}
		}
	}
}