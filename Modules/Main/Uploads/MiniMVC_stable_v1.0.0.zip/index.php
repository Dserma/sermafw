<?php
//MiniMVC - Github JPAKaagman
//Licensed under the GNU GPL License
namespace MiniMVC {
    //First thing you want to do, is starting a session
    if(session_status() == PHP_SESSION_NONE) {
        ini_set( 'session.cookie_httponly', 1 );
    	session_start();
    }
    
    //Load configuartion, so we could use the superglobals such as WEBSITE_FILEPATH
    include_once('corefiles/configuration.php');
    Core\Configuration::ConstructGlobalConfig();
    
    //Require the contoller files
    require_once(WEBSITE_FILEPATH . '/controllers/main.php');
    require_once(WEBSITE_FILEPATH . '/controllers/example.php');
    
    class Routing {
    	private $route;
    	private $pageFound;
    
    	public function __construct() {
    		$this->route = new Core\Route;
    		$this->AddRoutes();
    		$this->pageFound = $this->route->Submit();
    	}
    
    	private function AddRoutes() {
    		$this->route->Add('/', function() {
    			new Route\Main("home");
    		});
    		$this->route->Add('/.+', function($page) {
    			new Route\Main($page);
    		});
    		$this->route->Add('/example', function() {
    			new Route\Example("home");
    		});
    		$this->route->Add('/example/.+', function($null,$page) {
    			new Route\Example($page);
    		});
    		//New HASH, for testing only!
    		$this->route->Add('/newhash/.+', function($null,$pass) {
    			echo("Entered value = ".$pass."<br>The hash for this value = ".password_hash($pass, PASSWORD_BCRYPT));
    		});
    	}
    
    	public function __destruct() {
    		//destruction of the website, if page is not found then show a 404 error page
    		if(!$this->pageFound) {
    			new Route\Main("error");
    		}
    		//garbage collector
    		gc_collect_cycles();
    	}
    }
    new routing();
}