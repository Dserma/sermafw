<?php
//MiniMVC - Github JPAKaagman
//Licensed under the GNU GPL License
namespace MiniMVC\View {
    
    class Create {

    	public static function Page($filePath, $htmlData, $doContinue) {
    		$html = file_get_contents($filePath, FILE_USE_INCLUDE_PATH);
    
    		//array with values that should be replaced in the HTML document
    		//replace data in HTML page, which is loaded in the array $htmldata, {ARRAY_KEY} -> value
    		foreach ($htmlData as $key => $value) {
    			$html = str_replace("{{".$key."}}", $value, $html);
    		}
    		if($doContinue) {
    		    //Set some headers for protection
    		    header('X-Frame-Options: DENY');
    		    header('X-XSS-Protection: 1; mode=block');
    		    header('X-Content-Type-Options: nosniff');

    			echo($html);
    		}
    	}
    }
}